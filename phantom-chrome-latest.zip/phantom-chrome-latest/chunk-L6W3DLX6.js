import{a as t}from"./chunk-ETHRQ36O.js";import{cd as e}from"./chunk-C7UIWCFX.js";import{a as s}from"./chunk-GZ6YS23P.js";import{f as g,h as r,n as o}from"./chunk-DFBGNDRS.js";r();o();var a=g(s());var c=new t,p=({children:i})=>a.default.createElement(e,{storage:c},i);export{c as a,p as b};
//# sourceMappingURL=chunk-L6W3DLX6.js.map
