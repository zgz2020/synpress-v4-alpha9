import{a}from"./chunk-LQRE2LU5.js";import{a as p}from"./chunk-CBMCHMBG.js";import{a as i}from"./chunk-HJRPBBDR.js";import{j as c}from"./chunk-QKBEW6XH.js";import{p as o,rb as e,xa as m}from"./chunk-6GIRXPOU.js";import{S as l}from"./chunk-4G4LWPZS.js";import"./chunk-USRKY7I6.js";import{a as h}from"./chunk-GZ6YS23P.js";import{f as x,h as r,n}from"./chunk-DFBGNDRS.js";r();n();var t=x(h());var y=o.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100vh;
`,C=o.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex-grow: 1;
`,u=o(e).attrs({size:22,color:i.white,weight:"bold"})`
  margin-top: 16px;
  margin-left: 16px;
  margin-right: 16px;
`,v=o(e).attrs({size:16,color:i.grayLight})`
  margin-top: 8px;
  margin-left: 16px;
  margin-right: 16px;
`,w=({title:s,description:f,buttonText:g,onButtonClick:d})=>t.createElement(y,null,t.createElement(C,null,t.createElement(a,{color:l(i.warning,.1),diameter:94},t.createElement(m,{width:54,height:54,circleFill:i.warning})),t.createElement(u,null,s),t.createElement(v,null,f)),t.createElement(p,{removeFooterExpansion:!0},t.createElement(c,{theme:"primary",onClick:d},g))),E=w;export{w as WarningInfoModal,E as default};
//# sourceMappingURL=WarningInfoModal-6HS4CZGF.js.map
