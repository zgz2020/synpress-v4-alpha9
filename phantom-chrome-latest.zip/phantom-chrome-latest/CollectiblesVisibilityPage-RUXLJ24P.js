import{a as Z}from"./chunk-LA3F54PS.js";import{a as $}from"./chunk-WO4V6DFV.js";import{a as F}from"./chunk-JHBPC7Y6.js";import{a as G}from"./chunk-HTTT2FLK.js";import{Ka as j,x as V,z as O}from"./chunk-X7BGQIYK.js";import{k as U}from"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import{a as x}from"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import{g as z}from"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import{a as B}from"./chunk-MIHMJUVU.js";import"./chunk-KRKHMYSL.js";import"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import{a as Q}from"./chunk-CBMCHMBG.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import{D as A,G as E,a as P,b as D}from"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{j as _}from"./chunk-QKBEW6XH.js";import{E as N,p as s,sb as w}from"./chunk-6GIRXPOU.js";import"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import{$ as v,T as W,ba as L,ca as k,j as M}from"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import{Nd as H}from"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as p}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as T}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as y,h as S,n as I}from"./chunk-DFBGNDRS.js";S();I();var t=y(T());S();I();var o=y(T());var K=P({marginLeft:4}),X=s(x).attrs({align:"center",padding:"10px"})`
  background-color: #2a2a2a;
  border-radius: 6px;
  height: 74px;
  margin: 4px 0;
`,Y=s.div`
  display: flex;
  align-items: center;
`,R=s(B)`
  flex: 1;
  min-width: 0;
  text-align: left;
  align-items: normal;
`,tt=s(w).attrs({size:16,weight:600,lineHeight:19,noWrap:!0,maxWidth:"175px",textAlign:"left"})``,et=s(w).attrs({color:"#777777",size:14,lineHeight:17,noWrap:!0})`
  text-align: left;
  margin-top: 5px;
`,ot=s.div`
  width: 55px;
  min-width: 55px;
  max-width: 55px;
  height: 55px;
  min-height: 55px;
  max-height: 55px;
  aspect-ratio: 1;
  margin-right: 10px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
`,q=o.default.memo(e=>{let{t:n}=p(),{collection:i,unknownItem:m,isHidden:r,isSpam:a,onToggleHidden:d}=e,{name:c,id:h}=i,l=L(i),g=l?.chainData,f=k(i),u=v(l?.media,"image",!1,"small"),C=c||l?.name||m;return o.default.createElement(X,null,o.default.createElement(ot,null,a&&r?o.default.createElement(Z,{width:32}):u?o.default.createElement(O,{uri:u}):M(g)?o.default.createElement($,{...g.utxoDetails}):o.default.createElement(V,{type:"image",width:42})),o.default.createElement(x,null,o.default.createElement(R,null,o.default.createElement(Y,null,o.default.createElement(tt,null,C),a?o.default.createElement(N,{className:K,fill:D.colors.legacy.accentWarning,height:16,width:16}):null),o.default.createElement(et,null,n("collectiblesSearchNrOfItems",{nrOfItems:f})))),o.default.createElement(G,{id:h,label:`${c} visible`,checked:!r,onChange:b=>{d(b.target.checked?"show":"hide")}}))});var it=74,nt=10,lt=it+nt,st=20,rt=s.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
`,at=s.div`
  position: relative;
  width: 100%;
`,mt=()=>{let{handleHideModalVisibility:e}=j(),{data:n,isPending:i}=H(),{viewState:m,viewStateLoading:r}=W({account:n}),a=(0,t.useCallback)(()=>e("collectiblesVisibility"),[e]),d=(0,t.useMemo)(()=>({...m,handleCloseModal:a}),[a,m]),c=(0,t.useMemo)(()=>i||r,[i,r]);return{data:d,loading:c}},ct=t.default.memo(e=>{let{t:n}=p(),i=(0,t.useRef)(null);return(0,t.useEffect)(()=>{setTimeout(()=>i.current?.focus(),200)},[]),t.default.createElement(t.default.Fragment,null,t.default.createElement(at,null,t.default.createElement(z,{ref:i,tabIndex:0,placeholder:n("assetListSearch"),maxLength:50,onChange:e.handleSearch,value:e.searchQuery,name:"Search collectibles"})),t.default.createElement(U,null,t.default.createElement(A,null,({height:m,width:r})=>t.default.createElement(E,{style:{padding:`${st}px 0`},scrollToIndex:e.searchQuery!==e.debouncedSearchQuery?0:void 0,height:m,width:r,rowCount:e.listItems.length,rowHeight:lt,rowRenderer:a=>t.default.createElement(dt,{...a,data:e.listItems,unknownItem:n("assetListUnknownToken"),getIsHidden:e.getIsHidden,getIsSpam:e.getIsSpam,getSpamStatus:e.getSpamStatus,onToggleHidden:e.onToggleHidden})}))))}),dt=e=>{let{index:n,data:i,style:m,unknownItem:r,getIsHidden:a,getIsSpam:d,getSpamStatus:c,onToggleHidden:h}=e,l=i[n],g=a(l),f=d(l),u=c(l),C=(0,t.useCallback)(b=>h({item:l,status:b}),[h,l]);return t.default.createElement("div",{style:m},t.default.createElement(q,{collection:l,unknownItem:r,isHidden:g,isSpam:f,spamStatus:u,onToggleHidden:C}))},pt=()=>{let{data:e,loading:n}=mt(),{t:i}=p();return t.default.createElement(rt,null,n?t.default.createElement(F,null):t.default.createElement(ct,{...e}),t.default.createElement(Q,null,t.default.createElement(_,{onClick:e.handleCloseModal},i("commandClose"))))},Ut=pt;export{pt as CollectiblesVisibilityPage,Ut as default};
//# sourceMappingURL=CollectiblesVisibilityPage-RUXLJ24P.js.map
