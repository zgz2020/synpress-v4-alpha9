import{a as v}from"./chunk-CBMCHMBG.js";import{c as k}from"./chunk-KHXNW2QG.js";import{S as y,c as u,d as T}from"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import{j as b}from"./chunk-QKBEW6XH.js";import{_ as w,p as e,sb as d}from"./chunk-6GIRXPOU.js";import{Fc as x}from"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as h}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as I}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as H,h as f,n as g}from"./chunk-DFBGNDRS.js";f();g();var o=H(I());var A=16,D=e.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-bottom: 16px;
  height: 100%;
`,P=e.div`
  overflow: scroll;
`,M=e.div`
  margin: 45px 16px 16px 16px;
  padding-top: 16px;
`,z=e(k)`
  left: ${A}px;
  position: absolute;
`,B=e.div`
  align-items: center;
  background: #222;
  border-bottom: 1px solid #323232;
  display: flex;
  height: 46px;
  padding: ${A}px;
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
`,G=e.div`
  display: flex;
  flex: 1;
  justify-content: center;
`,W=e.footer`
  margin-top: auto;
  flex-shrink: 0;
  min-height: 16px;
`,F=e(d)`
  text-align: left;
`;F.defaultProps={margin:"12px 0px"};var $=e(d).attrs({size:16,weight:500,lineHeight:25})``;function L(r){let{actions:i,shortcuts:p,trackAction:n,onClose:s}=r;return(0,o.useMemo)(()=>{let m=i.more.map(t=>{let c=u[x(t.type)],l=t.isDestructive?"accentAlert":"textPrimary";return{start:o.default.createElement(c,{size:18,type:t.type,color:l}),topLeft:{text:t.text,color:l},onClick:()=>{n(t),s(),t.onClick(t.type)}}}),a=p?.map(t=>{let c=u[x(t.type)],l=t.isDestructive?"accentAlert":"textPrimary";return{start:o.default.createElement(c,{size:18,color:l}),topLeft:{text:t.text,color:l},onClick:()=>{n(t),s(),t.onClick(t.type)}}})??[];return[{rows:m},{rows:a}]},[i,s,p,n])}function N(r){let{t:i}=h(),{headerText:p,hostname:n,shortcuts:s}=r,C=L(r);return o.default.createElement(D,null,o.default.createElement(P,null,o.default.createElement(B,{onClick:r.onClose},o.default.createElement(z,null,o.default.createElement(w,null)),o.default.createElement(G,null,o.default.createElement($,null,p))),o.default.createElement(M,null,o.default.createElement(T,{gap:"section"},C.map((m,a)=>o.default.createElement(y,{key:`group-${a}`,rows:m.rows}))),o.default.createElement(W,null,n&&s&&s.length>0&&o.default.createElement(F,{color:"#777777",size:14,lineHeight:17},i("shortcutsWarningDescription",{url:n})))),o.default.createElement(v,{removeFooterExpansion:!0},o.default.createElement(b,{onClick:r.onClose},i("commandClose")))))}var X=N;export{N as CTAModal,X as default};
//# sourceMappingURL=Modal-U2AU5AP3.js.map
