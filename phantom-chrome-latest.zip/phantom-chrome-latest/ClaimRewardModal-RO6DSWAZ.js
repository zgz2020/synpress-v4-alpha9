import{a as M}from"./chunk-G7QRF4HP.js";import{a as I}from"./chunk-LQRE2LU5.js";import{a as B}from"./chunk-CBMCHMBG.js";import{ca as b}from"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import{h as E,j as m}from"./chunk-QKBEW6XH.js";import{_ as y,p as r,sb as a}from"./chunk-6GIRXPOU.js";import{b as F}from"./chunk-OTWAQNOL.js";import"./chunk-E3SVBH7I.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-X4PFTUHE.js";import"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as T}from"./chunk-FHPIWRKD.js";import{S as l}from"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as v}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as q,h as g,n as h}from"./chunk-DFBGNDRS.js";g();h();var o=q(v());var d=r.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 16px;
  justify-content: space-between;
`,p=r.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  flex: 1;
`,P=r(I)`
  margin-bottom: 20px;
`,u=r(a).attrs({size:28,weight:500})`
  margin-bottom: 8px;
  max-width: 85%;
`,C=r(a).attrs({size:16,weight:400,color:"#777"})`
  max-width: 85%;
`,Q=r.img`
  width: 225px;
  margin-bottom: 24px;
`,f=r(B)`
  height: auto;
  margin: 16px;
`,S=t=>{let{questId:i,networkIds:s}=t,{mutateAsync:n,data:e,isPending:x,isIdle:c,isError:w}=F(),k=async()=>{try{await n({questId:i,networkIds:s})}catch{}};return M(()=>{k()},i!==void 0&&s.length>0),(0,o.useMemo)(()=>({...t,data:e,isError:w,isLoading:x||c}),[t,e,x,c,w])},z=o.default.memo(({data:t,isLoading:i,isError:s,onPressDismiss:n})=>{let{t:e}=T();return i?o.default.createElement(d,null,o.default.createElement(p,null,o.default.createElement(P,{diameter:94,color:l("#AB9FF2",.2)},o.default.createElement(E,{diameter:60})),o.default.createElement(u,null,e("questsClaimInProgress")),o.default.createElement(C,null,e("questsVerifyingCompletion"))),o.default.createElement(f,{removeFooterExpansion:!0},o.default.createElement(m,{onClick:n},e("commandDismiss")))):s?o.default.createElement(d,null,o.default.createElement(p,null,o.default.createElement(P,{diameter:94,color:l("#EB3742",.2)},o.default.createElement(y,{width:30,height:30,fill:"#EB3742"})),o.default.createElement(u,null,e("questsClaimError")),o.default.createElement(C,null,e("questsClaimErrorDescription"))),o.default.createElement(f,{removeFooterExpansion:!0},o.default.createElement(m,{onClick:n},e("commandDismiss")))):t?o.default.createElement(d,null,o.default.createElement(b,null),o.default.createElement(p,null,o.default.createElement(Q,{src:t.imageUrl}),o.default.createElement(u,null,t.title),o.default.createElement(C,null,t.description)),o.default.createElement(f,{removeFooterExpansion:!0},o.default.createElement(m,{onClick:n},e("commandDismiss")))):null}),A=t=>{let i=S(t);return o.default.createElement(z,{...i})},Z=A;export{Z as default};
//# sourceMappingURL=ClaimRewardModal-RO6DSWAZ.js.map
