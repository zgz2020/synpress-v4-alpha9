import{a as At}from"./chunk-GOFDESAJ.js";import{a as et,b as Y,c as pt,d as ct,e as ut,f as ft,g as gt,h as ht,i as bt,k as Pt}from"./chunk-YMTZQVEB.js";import{a as Ke,b as Ye,d as nt}from"./chunk-4HUMYYTF.js";import"./chunk-BCCJIU7J.js";import"./chunk-BV2PSA7C.js";import"./chunk-2CVFSM6C.js";import"./chunk-RGUFPO2T.js";import"./chunk-3TXGUWHR.js";import"./chunk-CCO25AUY.js";import"./chunk-YKQBTVPZ.js";import"./chunk-HTTT2FLK.js";import"./chunk-O2VKBS6H.js";import"./chunk-ZVMDJATF.js";import"./chunk-F672X5ZC.js";import"./chunk-4RN3PQSS.js";import"./chunk-A7G3RXY5.js";import"./chunk-PDVYF4VQ.js";import"./chunk-QST4MS2A.js";import"./chunk-MUPQ6ZPZ.js";import{a as q}from"./chunk-G7QRF4HP.js";import"./chunk-AUOG6CT3.js";import"./chunk-K2OL5ZN2.js";import"./chunk-AIOERECL.js";import{Ka as j,La as lt,V as st,d as Ge,l as Qe}from"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import{b as at}from"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import{d as tt,g as ot,j as rt}from"./chunk-KRKHMYSL.js";import"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import"./chunk-CBMCHMBG.js";import"./chunk-PMGPRWKC.js";import{c as Oe}from"./chunk-5MHIOR4A.js";import{a as dt,b as mt,c as xt}from"./chunk-3LDZEQCT.js";import{b as yt}from"./chunk-L6W3DLX6.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import{j as Ve,l as U}from"./chunk-DXULVEAG.js";import{b as Se}from"./chunk-JLCEGUNG.js";import{T as Le,W as Ie,d as Q,da as He,e as X}from"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import{a as vt}from"./chunk-SANRYAL2.js";import{c as Re}from"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import{a as it}from"./chunk-HJRPBBDR.js";import{a as C,b as L}from"./chunk-QKBEW6XH.js";import{_ as Je,b as De,c as O,d as $e,e as We,f as Ue,g as K,h as qe,j as je,m as Xe,p as x,xa as Ze}from"./chunk-6GIRXPOU.js";import{a as Dt,b as _e}from"./chunk-Q4WYFSSZ.js";import{ea as Ne,eb as Ee}from"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import{e as W}from"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import{a as Ce,d as _}from"./chunk-ETHRQ36O.js";import{a as ke}from"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import{f as ce}from"./chunk-E3SVBH7I.js";import{Db as Me,Fb as Fe,Ib as ze,O as Pe,P as Ae,Q as Be,W as we,X as Te}from"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import{a as $t}from"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import{Dd as fe,Md as ge,Nd as he,Pa as le,Q as oe,T as re,Td as ye,Ud as be,Wd as ve,Xd as xe,bc as de,mc as me,pc as pe,wd as ue}from"./chunk-C7UIWCFX.js";import{J as ne}from"./chunk-RKVXP75K.js";import{m as E}from"./chunk-FHPIWRKD.js";import{S as v}from"./chunk-4G4LWPZS.js";import{Ya as H,ba as $,ka as ie,qa as ae,ta as se,z as te}from"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as M}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as T,h as l,n as d}from"./chunk-DFBGNDRS.js";l();d();var r=T(M()),Vt=T(Dt());l();d();var V=T(M());l();d();var J={container:"_1nscgt61 _51gazn1ar _51gazn1b4 _51gaznqm _51gaznvd _51gaznqp _51gaznt1 _51gaznxp _51gazn18w",notification:"_1nscgt63 _51gaznn0 _51gaznny _51gaznpu _51gaznow _51gaznbp _51gazn9a _51gazne4 _51gazn6v _51gaznkx _51gaznk3 _51gaznlr _51gaznj9 _51gaznqg _51gaznqe _51gaznqi _51gaznqc _51gazn2t2 _51gazn2jw _51gazn21k _51gazn2aq _51gazn1k2"};var Bt=()=>{let{data:[e]}=H(["enable-sidepanel-tx-notifications"]),t=Ye();if(e!==!0||!t)return null;let n={initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.5}},s={initial:{y:-40,opacity:0},animate:{y:0,opacity:1},exit:{y:40,opacity:0},transition:{duration:.5,ease:[.5,0,.2,1]}};return V.createElement(L,{mode:"wait"},V.createElement(C.div,{className:J.container,...n},V.createElement(C.div,{className:J.notification,key:t?.req?.id||"sidepanel",...s},V.createElement(Pt,null))))};l();d();var o=T(M());l();d();var y=T(M());var wt=({expired:e})=>{let{t}=E(),[n,s]=(0,y.useState)(!1),{data:m=[]}=fe("seedless-seeds-only"),{handleShowModalVisibility:c}=j(),f=m.length>0,g=(0,y.useCallback)(()=>{c("seedlessVerifyPinPage")},[c]);(0,y.useEffect)(()=>{e&&s(!1)},[e]);let p=(0,y.useCallback)(()=>{s(!0)},[]),h=(0,y.useCallback)(()=>{s(!0),g()},[g]);return!f||!e||n?null:y.default.createElement(Q,{padding:"screen",position:"absolute",insetX:0,zIndex:10,className:st.toastPosition},y.default.createElement(Le,{onClose:p,icon:"Info",actions:{children:t("seedlessVerifyPinVerifyButtonText"),onPress:h}},y.default.createElement(Q,{gap:8},y.default.createElement(X,{font:"captionSemibold",color:"bgWallet",children:t("seedlessVerifyToastPrimaryText")}),y.default.createElement(X,{font:"caption",color:"bgWallet",children:t("seedlessVerifyToastSecondaryText")}))))};l();d();l();d();l();d();l();d();l();d();async function Tt(e){let t=await oe.api().headers({Accept:"application/json"}).get(`/alert/v1?locale=${e}`);if(!re(t))throw new Error("Failed to retrieve Solana network health");return t.data}function Ct(e,t){return ie({queryKey:["solana","health",{locale:e}],refetchInterval:60*2500,enabled:t,async queryFn(){return await Tt(e)}})}function Z(e,t){let{data:n}=Ct(e,t);return t?n:void 0}var u=T(M());l();d();var F=T(M());var kt=(0,F.createContext)(null),St=()=>{let e=(0,F.useContext)(kt);if(!e)throw new Error("Missing banner context. Make sure you're wrapping your component in a <BannerProvider />");return e},Mt=({children:e})=>{let t=[],n=(p,h)=>{switch(h.type){case"create":return p.concat(h.payload);case"delete":return p.filter(({id:B})=>B!==h.payload.id);case"reset":return t;default:throw new Error("There was an error dispatching a banner action.")}},[s,m]=(0,F.useReducer)(n,t),c=p=>{let{type:h,variant:B,message:a,dismissable:b=!0,icon:S,autohide:A=!0,delay:z=5e3,onClick:D}=p;(!h||!B||!a)&&console.error("You must supply a type, variant and message when creating a Banner.");let I=ne();return m({type:"create",payload:{id:I,type:h,variant:B,message:a,dismissable:b,icon:S,autohide:A,delay:z,onClick:D}}),A&&setTimeout(()=>{f({id:I})},z),I},f=p=>m({type:"delete",payload:{id:p.id}}),g=()=>m({type:"reset"});return F.default.createElement(kt.Provider,{value:{banners:s,createBanner:c,deleteBanner:f,resetBanners:g}},e)};var Ft=x.button`
  cursor: ${e=>e.onClick?"pointer":"default"};
  display: flex;
  align-items: center;
  vertical-align: middle;
  overflow: visible;
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  border-width: 1px;
  border-style: solid;
  border-color: transparent;
  background-color: transparent;
  width: 100%;
  padding: 10px 16px;

  svg {
    fill: #fff;
    margin-right: 8px;
  }
`,Wt=x(C.div)`
  position: relative;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${e=>{switch(e.variant){case"primary":return v("#AB9FF2",.7);case"success":return v("#21E56F",.7);case"warning":return v("#E5A221",.7);case"danger":return v("#EB3742",.7);default:return v("#E5A221",.7)}}};

  ${Ft} {
    &:focus-visible {
      border-color: ${e=>{switch(e.variant){case"primary":return v("#AB9FF2",.7);case"success":return v("#21E56F",.7);case"warning":return v("#E5A221",.7);case"danger":return v("#EB3742",.7);default:return v("#E5A221",.7)}}};
    }
  }
`,Ut=x.p`
  color: #ffffff;
  font-size: 14px;
  font-weight: 500;
  line-height: 19px;
  text-align: left;

  svg {
    margin-right: 10px;
  }
`,qt=x.button`
  cursor: pointer;
  position: absolute;
  right: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  vertical-align: middle;
  margin: 0;
  padding: 0;
  overflow: visible;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  border-width: 1px;
  border-style: solid;
  border-color: transparent;
  background-color: transparent;

  &:focus,
  &:focus-visible {
    border-color: ${v("#FFFFFF",.3)};
  }

  svg {
    fill: #ffffff;
    margin: 0;
  }
`,jt=(e,t,n)=>{let{banners:s,createBanner:m,deleteBanner:c}=St(),f=s[s.length-1],{handleShowModalVisibility:g}=j(),{showSettingsMenu:p}=rt(),{t:h,i18n:B}=E(),{cluster:a}=e(),S=be().some(w=>le.isSolanaNetworkID(w)),A=Z(B.language,S),z=t(),D=n();(0,u.useEffect)(()=>{let w=s.find(N=>N.type==="testnet-mode");w&&c({id:w.id}),D?m({type:"testnet-mode",variant:"warning",message:h("featureNotSupportedOnLocalNet"),dismissable:!1,autohide:!1,onClick:()=>p(void 0,u.default.createElement(Y,null))}):z&&m({type:"testnet-mode",variant:"warning",message:h("connectionClusterTestnetMode"),dismissable:!1,autohide:!1,onClick:()=>p(void 0,u.default.createElement(Y,null))})},[D,z,h]),(0,u.useEffect)(()=>{if(!a)return;let w=s.find(N=>N.type==="network-health");if(a==="mainnet-beta"){if(A){let{bannerVariant:N,bannerMessage:G,notificationMessageTitle:R,notificationMessage:ee}=A;!!N&&!!G?G!==w?.message&&m({type:"network-health",variant:N,message:G,dismissable:!1,icon:u.default.createElement(Ze,{width:14,height:14,circleFill:"#FFFFFF",exclamationFill:"transparent"}),autohide:!1,onClick:ee&&R?()=>g("networkHealth",{variant:N,title:R,message:ee}):void 0}):w&&c({id:w.id})}}else w&&c({id:w.id})},[a,A]);let I=(0,u.useCallback)(()=>{f&&c({id:f.id})},[c,f]);return{banner:f,dismissBanner:I}},Gt=u.default.memo(e=>{let{banner:t,dismissBanner:n}=e;return u.default.createElement(L,null,t&&u.default.createElement(Wt,{key:"banner",role:"banner","aria-live":t?.autohide?"assertive":"polite","aria-atomic":"true",variant:t.variant,initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},transition:{ease:"easeOut",duration:.2}},u.default.createElement(Ft,{tabIndex:t.onClick?1:-1,onClick:t.onClick},t.icon,u.default.createElement(Ut,null,t.message)),t.dismissable&&u.default.createElement(qt,{onClick:n},u.default.createElement(Je,{width:14,fill:"#FFFFFF"}))))}),Qt=()=>{let e=jt(ze,ve,xe);return u.default.createElement(Gt,{...e})},zt=()=>u.default.createElement(Qt,null);l();d();var i=T(M());l();d();var Nt=T($t()),k=T(M());var Xt=x(C.div)`
  position: absolute;
  top: 0px;
  left: 0;
  width: 0;
  height: 2px;
  background-color: #ab9ff2;
`,Et=({refs:e,activeRoute:t,onFinishedAnimating:n,isAnimating:s})=>{let[{x:m,width:c},f]=(0,k.useState)({x:0,width:0}),g=(0,k.useCallback)(()=>{e&&e[t]&&e[t].current&&f({x:e[t].current.offsetLeft,width:e[t].current.getBoundingClientRect().width})},[t,e]);return(0,k.useEffect)(()=>{g()},[t,e,g]),(0,k.useEffect)(()=>{let p=(0,Nt.default)(()=>{g()},500);return self.addEventListener("resize",p),()=>{self.removeEventListener("resize",p)}}),k.default.createElement(Xt,{animate:{x:m,width:c},style:{opacity:s?1:0},onAnimationComplete:n,transition:{duration:.4,type:"spring"}})};var _t=.1,Lt=10,Kt=60,Yt=x.div`
  position: relative;
  height: ${Kt}px;
  display: flex;
`,Jt=x(C.div)`
  flex: 1;
  overflow-x: hidden;
  padding: ${({padding:e})=>typeof e=="number"?e:16}px;
`,Zt=x(nt)`
  flex: 1;
  display: flex;
  justify-content: space-around;
  padding: 0px 10px;
`,Ht=i.default.memo(({items:e})=>{let t=O(),n=tt(t),[s,m]=(0,i.useState)(!1),c=(0,i.useMemo)(()=>e.find(a=>De({path:`/${a.route}`,end:!0},t.pathname)),[e,t.pathname]),f=c&&c.route,g=(0,i.useMemo)(()=>e.reduce((a,b)=>(a[b.route]=(0,i.createRef)(),a),{}),[e]),p=t.pathname!=n?.pathname&&n?.pathname!=null,h=(0,i.useMemo)(()=>e.map(a=>{let b=i.default.memo(()=>{let S=0;return p&&(S=Rt(e,t.pathname,n?.pathname??"")?Lt:-Lt),i.default.createElement(Jt,{id:"tab-content","data-testid":`tab-content-${a.route}`,initial:{x:S,opacity:0},animate:{x:0,opacity:1},exit:{opacity:0},transition:{duration:_t},padding:a.padding},i.default.createElement(ot,{shouldResetOnAccountChange:!0},a.renderContent()))});return i.default.createElement(K,{key:a.route,path:`/${a.route}`,element:i.default.createElement(b,null)})}),[e,t]),B=(0,i.useCallback)(a=>{m(!0),_.capture("tabPress",{data:{target:a}}),se.addBreadcrumb("generic",`Tab changed to ${a}`,"info")},[]);return i.default.createElement(i.default.Fragment,null,i.default.createElement(L,{mode:"wait",initial:!1},i.default.createElement(qe,{location:t,key:t.pathname},h,i.default.createElement(K,{key:"redirection",element:i.default.createElement(C.div,{exit:{opacity:0},transition:{duration:_t}},i.default.createElement(Ue,{to:e[0]?e[0].route:"/"}))}))),i.default.createElement(Yt,null,i.default.createElement(Et,{refs:g,activeRoute:f,onFinishedAnimating:()=>m(!1),isAnimating:s}),i.default.createElement(Zt,{role:"tablist","aria-orientation":"horizontal"},e.map(a=>i.default.createElement(to,{isActive:f===a.route,key:a.route,item:a,ref:g[a.route],isAnimating:s,onClick:()=>B(a.route)})))),i.default.createElement("div",{"aria-hidden":!0,"data-testid":"current-route","data-location":t.pathname}))},(e,t)=>Fe(e.items.map(n=>n.route),t.items.map(n=>n.route))),Rt=(e,t,n)=>{let s=e.findIndex(c=>c.route===It(t)),m=e.findIndex(c=>c.route===It(n));return s>m},It=e=>e==="/"?e:e.replace(/^\/+/g,""),eo=x(je)`
  display: block;
  padding: 15px 0px;
  margin: 0px 12px;
  position: relative;
  width: 100%;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  :hover {
  }
  :after {
    content: "";
    position: absolute;
    top: -1px;
    left: 0;
    height: 2px;
    width: 100%;
    border-radius: 2px;
    ${e=>e.$isActive&&!e.$isAnimating&&"background-color: #AB9FF2;"}
    ${e=>e.$isAnimating&&"background-color: transparent;"}
  }
`,to=(0,i.forwardRef)(({isActive:e,item:t,isAnimating:n,onClick:s},m)=>i.default.createElement(eo,{"aria-label":t.label,"data-testid":`bottom-tab-nav-button-${t.route}`,$isActive:e,$isAnimating:n,to:t.route,ref:m,onClick:s},t.renderButton({isActive:e})));var oo=o.default.lazy(()=>import("./HomeTabPage-HFBTXD3Z.js")),ro=o.default.lazy(()=>import("./CollectionsPage-IHU3JYHO.js")),no=o.default.lazy(()=>import("./SwapTabPage-R5TD6F7J.js")),io=o.default.lazy(()=>import("./RecentActivity-2QG6VOHU.js")),ao=o.default.lazy(()=>import("./ExploreTabPage-SV6CGGLT.js")),so=o.default.lazy(()=>import("./HomeHeaderRightButtons-635YG3FM.js")),lo=o.default.lazy(()=>import("./SwapSettingsButton-6GX75JQJ.js")),Ot=()=>{let{data:e=[]}=ue();ye();let{data:[t]}=H(["frontend-enable-session-start"]),{mutateAsync:n}=ce();q(()=>{bt.onAppSessionStart(e)},e.length>0&&t);let{mutate:s}=Ne();return q(()=>{s()},!0),q(()=>{n()},te),o.default.createElement(o.default.Fragment,null,o.default.createElement(mo,null),o.default.createElement(zt,null),o.default.createElement(po,null),o.default.createElement("div",{id:W}))},mo=()=>{let{pathname:e}=O(),t=(0,o.useMemo)(()=>e==="/swap"?o.default.createElement(lo,null):e==="/"?o.default.createElement(so,null):null,[e]);return o.default.createElement(ft,{rightMenuButton:t})},po=()=>{let{data:e}=ge(),{data:t}=he({authRepository:U}),{data:[n]}=H(["enable-pin-verification-timer"]),{data:s}=Qe(n),m=t?.isReadOnly,c=$.isFeatureEnabled("kill-swapper")||m,f=$.isFeatureEnabled("kill-explore"),g=$.isFeatureEnabled("kill-collectibles"),{t:p}=E(),{pathname:h}=O(),B=$e(),{closeAllModals:a}=at();Me(),(0,o.useEffect)(()=>{a(),h!=="/"&&B("/")},[e]);let b=(0,o.useCallback)(A=>({isActive:z})=>o.default.createElement(He,{animationName:A,isActive:z}),[]),S=(0,o.useMemo)(()=>[{label:p("homeTab"),route:"/",renderButton:b("tabBarHome"),renderContent:()=>o.default.createElement(oo,null),padding:0},g?null:{label:p("collectiblesTab"),route:"/collectibles",renderButton:b("tabBarCollectibles"),renderContent:()=>o.default.createElement(ro,null)},c?null:{label:p("swapTab"),route:"/swap",renderButton:b("tabBarSwapper"),renderContent:()=>o.default.createElement(no,null)},{label:p("activityTab"),route:"/notifications",renderButton:b("tabBarActivity"),renderContent:()=>o.default.createElement(io,null)},f?null:{label:p("exploreTab"),route:"/explore",renderButton:b("tabBarExplore"),renderContent:()=>o.default.createElement(ao,null),padding:0}].filter(A=>A!==null),[g,f,c,p,b]);return o.default.createElement(o.Suspense,null,o.default.createElement(wt,{expired:s?.expired??!1}),o.default.createElement(Ht,{items:S}))};ke();ae.init({provider:vt});_e();Be(new Ce);Pe((e,t)=>we(e,t,_));Ae(Te);var co=()=>{let[e,t]=(0,r.useState)(!1);(0,r.useEffect)(()=>{async function s(){let m=await Oe();m!=e&&t(m)}s()},[]),(0,r.useEffect)(()=>{_.capture("popupOpen")},[]);let n=(0,r.useCallback)(()=>{Se({url:"onboarding.html"}),self.close()},[]);return r.default.createElement(r.default.Fragment,null,r.default.createElement(We,{future:{v7_startTransition:!0}},r.default.createElement(Xe,{theme:it},r.default.createElement(Ie,null,r.default.createElement(xt,{backgroundColor:"#222222"}),r.default.createElement(Re,null,r.default.createElement(et,{withBorder:!0},r.default.createElement(yt,null,r.default.createElement(Ve,null,r.default.createElement(me,{analytics:_},r.default.createElement(Mt,null,r.default.createElement(Ee,null,r.default.createElement(de,{authRepository:U},r.default.createElement(pe,{userRepository:mt,claimUsernameSigner:dt},r.default.createElement(Ge,{seedlessRepository:At},r.default.createElement(ct,{openOnboarding:n},r.default.createElement(ht,null,r.default.createElement(lt,null,r.default.createElement(pt,null,r.default.createElement(ut,null,r.default.createElement(Ot,null))))))),e&&r.default.createElement(Ke,null,r.default.createElement(Bt,null)))))),r.default.createElement("div",{id:W}),r.default.createElement(gt,null))))))))))},uo=document.getElementById("root"),fo=(0,Vt.createRoot)(uo);fo.render(r.default.createElement(co,null));
//# sourceMappingURL=Popup.js.map
