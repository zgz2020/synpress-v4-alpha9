import{a as n}from"./chunk-GZ6YS23P.js";import{f as i,h as o,n as a}from"./chunk-DFBGNDRS.js";o();a();var t=i(n()),s=(0,t.createContext)({}),l=()=>{let e=(0,t.useContext)(s);if(!e)throw new Error("Missing modal context");return e};export{s as a,l as b};
//# sourceMappingURL=chunk-LVT7IYXJ.js.map
