import{a as D}from"./chunk-PPXUY6SE.js";import{a as C,e as S}from"./chunk-SBNVSNC5.js";import{S as I,b as y,d as h,e as f}from"./chunk-W7GOV3UN.js";import{W as P,p as i,x as L}from"./chunk-6GIRXPOU.js";import{d as k}from"./chunk-ETHRQ36O.js";import{z as T}from"./chunk-E3SVBH7I.js";import{Pb as B}from"./chunk-5E46BDWA.js";import{Jb as b}from"./chunk-C7UIWCFX.js";import{m as V}from"./chunk-FHPIWRKD.js";import{L as z}from"./chunk-4G4LWPZS.js";import{a as w}from"./chunk-GZ6YS23P.js";import{f as v,h as p,n as g}from"./chunk-DFBGNDRS.js";p();g();var t=v(w());p();g();var R={header:"_14rx5di1 _51gazn4e _51gazn34 _51gazn5o _51gazn1u _51gazn18w _51gazn1c3 _51gazn1b8 _51gazngj _51gazn1zw _51gaznlr _51gaznqi",summaryContainer:"_51gaznnf _51gaznod _51gaznq9 _51gaznpb _51gazn129 _51gazn1kw"};p();g();var c=v(w()),A=c.default.memo(({address:e,networkID:o,showConcise:n})=>{let{t:s}=V(),{getExistingAccount:a,getKnownAddressLabel:x}=T(),{data:d}=B(e,o,s);if(!e)return null;let r=a(e),m=x(e,o),u=r?r.name:m;return d?c.default.createElement(f,null,e," ",c.default.createElement(f,{color:"textSecondary"},"(",b(d,4),")")):u?c.default.createElement(f,null,u," ",c.default.createElement(f,{color:"textSecondary"},"(",b(e,4),")")):c.default.createElement(f,null,n?b(e,4):e)});function F(e){if(!e)return{};let o=e.split(" ").map(n=>n.replace("px","")).map(n=>parseInt(n,10));return o.length===1?{borderTopLeftRadius:o[0],borderTopRightRadius:o[0],borderBottomRightRadius:o[0],borderBottomLeftRadius:o[0]}:o.length===2?{borderTopLeftRadius:o[0],borderTopRightRadius:o[1],borderBottomRightRadius:o[0],borderBottomLeftRadius:o[1]}:{borderTopLeftRadius:o[0],borderTopRightRadius:o[1],borderBottomRightRadius:o[2],borderBottomLeftRadius:o[3]}}var O=i.div`
  display: flex;
  flex-direction: column;
  border-bottom: 1px solid #222222;
  border-bottom-width: ${e=>e.border?1:0}px;
  padding: ${e=>e.padding?e.padding:14}px;
  cursor: ${e=>e.onClick?"pointer":"default"};
`,_=i.div`
  padding-top: 3px;
`,j=i.div`
  display: flex;
  justify-content: space-between;
  font-size: ${e=>e.fontSize?e.fontSize:14}px;
`,E=i.div`
  display: flex;
  justify-content: space-between;
`,M=i.div`
  text-align: left;
  flex: 1;
`,H=i.div`
  text-align: right;
  flex: 1;
`,W=i.div`
  display: flex;
  align-items: center;
  ${e=>e.truncate?"flex: 1; min-width: 0; justify-content:end;":""}
`,q=i.div`
  padding-left: 8px;
  color: #999;
`,$=({children:e,showArrow:o})=>t.createElement(W,{truncate:!o},e,o&&t.createElement(q,null,t.createElement(L,{height:12}))),l=i.span`
  color: ${e=>e.color||"white"};
  text-align: ${e=>e.align||"left"};
  font-weight: ${e=>e.weight||400};
  overflow-wrap: break-word;
  ${e=>e.margin?"margin: "+e.margin+";":""};
  ${e=>e.size?"font-size: "+e.size+"px;":""}
  ${e=>e.truncate?"white-space: nowrap; text-overflow: ellipsis; overflow:hidden; width: 100%;"+(e.size?"line-height: "+e.size*1.2+"px;":"line-height: 17px;"):""}
`,U=i.a.attrs({target:"_blank",rel:"noopener noreferrer"})`
  color: #ab9ff2;
  text-decoration: none;
  cursor: pointer;
`,K=i.div`
  text-align: center;
  width: 100%;
`,G=({children:e,label:o,tooltipContent:n,fontSize:s})=>t.createElement(t.Fragment,null,t.createElement(S,{tooltipAlignment:"topLeft",iconSize:12,lineHeight:17,fontSize:s,fontWeight:500,info:n?t.createElement(C,null,n):null},o),e),J=e=>{k.capture("historyItemDetailLinkClicked",{data:{hostname:z(e)}})},Q=e=>"designSystemOptIn"in e&&e.designSystemOptIn===!0?t.createElement(X,{...e}):t.createElement(Y,{...e}),X=({header:e,rows:o,borderRadius:n})=>{let s=F(n);return t.createElement(h,{className:R.summaryContainer,...s},e?t.createElement("div",{className:R.header},e):null,t.createElement(I,{rows:o.map(a=>({...a.onPress?{onClick:a.onPress}:{},topLeft:a.tooltipContent?{component:()=>t.createElement(S,{textColor:y.colors.legacy.textSecondary,iconColor:y.colors.legacy.textSecondary,tooltipAlignment:"topLeft",iconSize:12,lineHeight:17,fontSize:14,fontWeight:500,info:t.createElement(C,null,a.tooltipContent)},a.label)}:{text:a.label,font:"captionMedium",color:"textSecondary"},topRight:{text:a.value,font:"captionMedium",color:"textPrimary"}}))}))},Y=({header:e,rows:o,borderRadius:n,padding:s,fontSize:a,networkID:x})=>{let d=F(n);return t.createElement(h,{className:R.summaryContainer,...d}," ",e?t.createElement("div",{className:R.header},e):null,o.map((r,m)=>{if(r.value===void 0)return null;let u=r.onClick?{role:"button"}:void 0;return t.createElement(O,{border:o.length-1!==m,padding:s,onClick:r.onClick,key:`summary-row-${m}`,...u},t.createElement(j,{key:r.label,fontSize:a},typeof r.value=="string"?r.type==="link"?t.createElement(K,null,t.createElement(U,{href:r.value,onClick:()=>J(r.value)},r.label)):t.createElement(G,{label:r.label,tooltipContent:r.tooltipContent,fontSize:a},t.createElement($,{showArrow:!!r.onClick},r.type==="address"?t.createElement(A,{address:r.value,networkID:x??"solana:101"}):t.createElement(l,{color:r.color,weight:500,align:"right",truncate:!r.onClick},r.value))):t.createElement(t.Fragment,null,t.createElement(l,{color:"#777777",size:a},r.label),t.createElement($,{showArrow:!!r.onClick},r.value))),t.createElement(E,null,r.leftSubtext?t.createElement(M,null,t.createElement(_,null,t.createElement(l,{color:r.leftSubtextColor||"#777777",size:13},r.leftSubtext))):null,r.rightSubtext?t.createElement(H,null,t.createElement(_,null,t.createElement(l,{color:r.rightSubtextColor||"#777777",size:13},r.rightSubtext))):null))}))},tt=({name:e,imageURL:o})=>t.createElement("div",{style:{display:"flex",flexDirection:"row",alignItems:"center"}},t.createElement(D,{iconUrl:o,width:16}),t.createElement(l,{margin:"0 0 0 5px",weight:500},e)),Z=i.div`
  height: 100%;
  overflow: scroll;
  margin-top: -16px;
  padding-top: 16px;
  padding-bottom: 64px;
`,ee=i.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`,te=i.div`
  margin-top: 10px;
  margin-bottom: 10px;
`,oe=i.div`
  margin-top: 10px;
  margin-bottom: 20px;
`,re=i.div`
  margin-bottom: 10px;
`,ie=i.div`
  position: relative;
  width: 100%;
  text-align: center;
  margin: 10px 0 10px 0;
`,ne=i(l)`
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  max-width: 100%;
`,ae=i.div`
  background-color: #ffdc62;
  width: 100%;
  margin-top: 24px;
  margin-bottom: 14px;
  border-radius: 9px;
  padding: 16px;
  gap: 8px;
  display: flex;
  align-items: flex-start;
  align-self: stretch;
`,le=i.div`
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  display: flex;
  justify-content: center;
  align-items: center;
`,ot=({title:e,primaryText:o,secondaryText:n,image:s,sections:a,leftButton:x,warning:d})=>t.createElement(Z,null,t.createElement(ee,null,t.createElement(ie,null,x||!1,t.createElement(l,{weight:500,size:22},e)),t.createElement(te,null,s),o.value&&t.createElement(ne,{weight:600,size:34,color:o.color,align:"center",margin:"10px 0 10px 0"},o.value),n.value&&t.createElement(l,{size:16,color:"#777777",margin:"0 0 10px 0"},n.value),d&&t.createElement(ae,null,t.createElement(le,null,t.createElement(P,null)),t.createElement(l,{size:14,color:"#222222",margin:"3px 0px 3px 8px"},d))),a.map(({title:r,rows:m},u)=>t.createElement(oe,{key:`summary-item-${u}`},r&&t.createElement(re,null,t.createElement(l,{size:14,weight:500,color:"#777777"},r)),t.createElement(Q,{rows:m}))));export{G as a,Q as b,tt as c,ot as d};
//# sourceMappingURL=chunk-6MGZDMDL.js.map
