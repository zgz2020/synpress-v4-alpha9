import{a}from"./chunk-GBGLUPZY.js";import{a as d}from"./chunk-4OIQVFXM.js";import{ja as l,p as o}from"./chunk-6GIRXPOU.js";import{b as t}from"./chunk-E5NQVP5E.js";import{a as u}from"./chunk-GZ6YS23P.js";import{f as p,h as n,n as m}from"./chunk-DFBGNDRS.js";n();m();var e=p(u());var b=o.div`
  border-radius: 8px;
  flex: 1;
  align-items: center;
  justify-content: center;
  padding: 8px;
`,c=o(a)`
  max-width: 100%;
  max-height: 100%;
`,I=o.div`
  flex-basis: 75px;
`,y=e.default.memo(s=>{let{uri:g,width:r,height:i,borderRadius:h}=s;return e.default.createElement(e.default.Fragment,null,e.default.createElement(c,{src:g,fallback:e.default.createElement(b,null,e.default.createElement(l,null)),width:r||t,height:i||t,loader:e.default.createElement(I,null,e.default.createElement(d,{width:"75px",height:"75px",borderRadius:"8px",backgroundColor:"#434343"})),style:{borderRadius:h,...r?{width:r}:null,...i?{height:i}:null},hidden:status==="loading"}))});export{y as a};
//# sourceMappingURL=chunk-CWZ2S6D6.js.map
