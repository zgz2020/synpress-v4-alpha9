import{a as ue}from"./chunk-6RQSKOQP.js";import{a as D}from"./chunk-XZJRQSZY.js";import"./chunk-RT4N3TM6.js";import{a as me}from"./chunk-37XRAS64.js";import"./chunk-HTTT2FLK.js";import{a as le,b as ce,c as de}from"./chunk-O2VKBS6H.js";import"./chunk-K2OL5ZN2.js";import"./chunk-AIOERECL.js";import{G as pe,Ka as A}from"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import{h as B}from"./chunk-KRKHMYSL.js";import"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import{a as ae}from"./chunk-CBMCHMBG.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import{P as N,Q as te,d as ee,v as oe}from"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{a as V,b as I,j as h}from"./chunk-QKBEW6XH.js";import{$ as ne,d as ie,l as re,p as m,sb as P,va as se}from"./chunk-6GIRXPOU.js";import{La as K,Ya as Z,Za as J,ab as X,ia as q,sa as G,ta as Y}from"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import{p as Q}from"./chunk-FZCSOTU6.js";import{v as U}from"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import{Nd as v,Pa as k}from"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as x}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as F}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as L,h as S,n as g}from"./chunk-DFBGNDRS.js";S();g();var t=L(F());S();g();var i=L(F());S();g();var n=L(F());var Se=m.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  width: 100%;
  padding: ${e=>e.addScreenPadding?"16px":"0"};
`,Le=m.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex-grow: 1;
`,Fe=m.div`
  width: 100%;
  > * {
    margin-top: 10px;
  }
  padding: 16px;
`,Ne=m.div`
  display: flex;
  justify-content: flex-end;
  position: absolute;
  width: 100%;
  padding: 16px;
`,Ve=m.div`
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`,co=m.div`
  position: relative;
`,uo=m.div`
  position: absolute;
  top: 0;
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  svg {
    fill: #21e56f;
  }
`,Ie=m(P).attrs({size:28,weight:500,color:"#FFFFFF"})`
  margin-top: 24px;
  margin-left: 12px;
  margin-right: 12px;
`,we=m(P).attrs({size:16,weight:400,color:"#999999"})`
  margin-top: 9px;
  margin-left: 12px;
  margin-right: 12px;
  span {
    color: #999999;
    font-weight: bold;
  }
`,De=m(P).attrs({size:16,weight:500,color:"#AB9FF2"})`
  margin-top: 18px;
  text-decoration: none;
  ${e=>e.opacity!==0&&re`
      &:hover {
        cursor: pointer;
        color: #e2dffe;
      }
    `}
`,He=({description:e,header:r,icon:o,onClose:s,title:a,txLink:p,isClosable:c,disclaimer:d})=>{let{t:l}=x(),u=()=>{p&&self.open(p)};return n.default.createElement(Se,null,r,n.default.createElement(Le,null,n.default.createElement(I,{mode:"wait",initial:!0},n.default.createElement(V.div,{key:a,initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.2}},o)),n.default.createElement(Ie,null,a),n.default.createElement(we,null,e),p&&n.default.createElement(I,{mode:"wait",initial:!1},n.default.createElement(V.div,{key:p,initial:{opacity:0,y:16},animate:{opacity:1,y:0},exit:{opacity:0},transition:{duration:.2}},n.default.createElement(De,{opacity:1,onClick:u},l("swapTxConfirmationViewTransaction"))))),c&&s?n.default.createElement(Fe,null,n.default.createElement(we,null,d),c&&s?n.default.createElement(h,{onClick:s},l("commandClose")):null):null)};var ge=({ledgerAction:e,numberOfTransactions:r,cancel:o,ledgerApp:s})=>n.default.createElement(Se,{addScreenPadding:!0},n.default.createElement(ce,{ledgerAction:e,numberOfTransactions:r,cancel:o,ledgerApp:s}));var Me=e=>self.open(e,"_blank"),xe=({txErrorTitle:e,txErrorMessage:r,txErrorHelpButtonLink:o,txLink:s,onClose:a})=>n.default.createElement(He,{header:n.default.createElement(Ne,null,n.default.createElement(Ve,{onClick:()=>Me(o)},n.default.createElement(ne,{fill:"white"}))),icon:n.default.createElement(me,{type:"failure"}),description:r,onClose:a,title:e,txLink:s,isClosable:!0});var $e=e=>self.open(e,"_blank"),Re=()=>{let{handleHideModalVisibility:e}=A(),r=ie(),{popDetailView:o}=B(),{data:s}=v(),p=s?.type==="ledger",c=(0,i.useCallback)(()=>{e("swapReview")},[e]),d=(0,i.useCallback)(()=>{o()},[o]),l=(0,i.useCallback)(()=>{c(),r("/notifications")},[c,r]);return X({isLedger:p,goToSwapTab:c,goToSwapReview:d,goToActivityTab:l})},We=({txError:e,txErrorTitle:r,txErrorMessage:o,txErrorHelpButtonLink:s,txLink:a,executeSwap:p,numberOfTransactions:c,addressType:d,onClose:l})=>le(e)?i.default.createElement(de,{ledgerActionError:e,onRetryClick:p,onCancelClick:l}):e?i.default.createElement(xe,{txErrorTitle:r,txErrorMessage:o,txLink:a,onClose:l,txErrorHelpButtonLink:s}):i.default.createElement(ge,{ledgerAction:p,numberOfTransactions:c,cancel:l,ledgerApp:Q(d)}),Oe=i.default.memo(e=>{let r=(0,i.useRef)(null),{t:o}=x(),s=o("swapTxConfirmationViewTransaction"),{addressType:a,executeSwap:p,isLedger:c,isBridge:d,sellAsset:l,buyAsset:u,estimatedTime:T,isFailure:Ce,isSuccess:ye,isClosable:be,notEnoughSol:ke,numberOfTransactions:ve,txError:he,txErrorTitle:H,txErrorMessage:M,txLink:E,txErrorHelpButtonLink:$,onClose:R}=e,[W,Pe]=(0,i.useState)(!1),w,f,O,C,j=o("commandClose"),_,y,b=be||!1;if((0,i.useEffect)(()=>{!y&&setTimeout(()=>{!W&&r.current?.start(),Pe(!0)},200)},[W,y]),c&&!E)return i.default.createElement(We,{isBridge:d,txError:he,txErrorTitle:H,txErrorMessage:M,txErrorHelpButtonLink:$,txLink:E,numberOfTransactions:ve,addressType:a,executeSwap:p,onClose:R});if(d&&l){let z=`${l.amount} ${l.symbol}`,Be=k.getNetworkName(l.networkID),Ae=`${u.amount} ${u.symbol}`,Ee=k.getNetworkName(u.networkID);w=o("swapTxBridgeSubmitting"),f=o("swapTxBridgeSubmittingDescription",{sellAmount:z,sellNetwork:Be,buyAmount:Ae,buyNetwork:Ee})}else f=`${u.symbol||o("swapTxConfirmationTokens")} ${o("swapTxConfirmationTokensWillBeDeposited")} `,w=o("swapTxConfirmationSwappingTokens");return ke&&(w=o("notEnoughSolPrimaryText"),f=o("notEnoughSolSecondaryText"),y=i.default.createElement(se,{width:N,height:N}),C={theme:"primary"},b=!0),ye&&(d?(w=o("swapTxBridgeSubmitted"),f=o("swapTxBridgeSubmittedDescription",{estimatedTime:T}),O=o("swapTxBridgeSubmittedDisclaimer")):(w=o("swapTxConfirmationTokensDepositedTitle"),f=o("swapTxConfirmationTokensDepositedBody")),C={theme:"primary"},b=!0,r.current?.success()),Ce&&(w=H,f=M,C={theme:"secondary"},j=o("commandClose"),b=!0,_=i.default.createElement(ee,{alignItems:"flex-end"},i.default.createElement(oe,{icon:"HelpCircle",size:32,onClick:()=>$e($),backgroundColor:"bgWallet",color:"textSecondary",label:o("commandHelp")})),r.current?.fail()),i.default.createElement(te,{ref:r,title:w,txLink:E,txTitle:s,description:f,disclaimer:O,isClosable:b,buttonVariant:C,buttonText:j,onClose:R,header:_,customIcon:y})}),Te=()=>{let e=Re();return(0,i.useEffect)(()=>{!e.isReadyToExecute||e.isLedger||e.executeSwap()},[e.isReadyToExecute,e.isLedger]),i.default.createElement(Oe,{...e})};var je=m.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  overflow-y: scroll;
  padding: 16px 16px ${78}px; // footer height + padding
`,_e=m.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
`,ze=m.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  padding: 16px;
  position: absolute;
  bottom: 0;
`,Qe=m.div`
  background-color: #2a2a2a;
  border-radius: 6px;
  width: 100%;

  > *:first-child {
    border-bottom: 1px solid #222222;
  }
`,Ue=()=>{let{t:e}=x(),{handleHideModalVisibility:r}=A(),{pushDetailView:o}=B(),{resume:s}=G(),a=q(T=>T.quoteResponse),{data:p}=v(),c=(0,t.useMemo)(()=>p?.addresses.find(T=>T.networkID===a?.sellToken.chainId),[p,a]);(0,t.useEffect)(()=>{K()},[]),U(c,"SWAP_FUNGIBLE");let d=(0,t.useCallback)(()=>o(t.default.createElement(Te,null)),[o]),l=Y({goToConfirmation:d}),u=(0,t.useCallback)(()=>{s(),r("swapReview")},[r,s]);return{...l,hideSwapReview:u,t:e}},qe=t.default.memo(({buyToken:e,sellToken:r,hideSwapReview:o,onSwap:s,t:a})=>{let{infoRowDisplayStrategy:p}=J();return t.default.createElement(je,null,t.default.createElement(_e,null,t.default.createElement(pe,{leftButton:{type:"close",onClick:o}},a("swapReviewFlowPrimaryText")),t.default.createElement(Qe,null,t.default.createElement(D,{...r,title:a("swapReviewFlowYouPay")}),t.default.createElement(D,{...e,title:a("swapReviewFlowYouReceive")})),t.default.createElement(ue,{isSwapReview:!0,rowDisplayStrategy:p})),t.default.createElement(ze,null,t.default.createElement(ae,{removeFooterExpansion:!0,removeShadowFooter:!0},t.default.createElement(h,{theme:"primary",onClick:s},a("swapReviewFlowActionButtonPrimary")))))}),Ge=()=>{let e=Ue();return t.default.createElement(Z,null,t.default.createElement(qe,{...e}))},Ye=()=>t.default.createElement(Ge,null),Jo=Ye;export{Ye as SwapReviewPage,Jo as default};
//# sourceMappingURL=SwapReviewPage-MZ7SYN7G.js.map
