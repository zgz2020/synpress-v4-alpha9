import{a as O,c as V}from"./chunk-W4AVGRUP.js";import{a as G}from"./chunk-7DJ4CCJR.js";import{j as W}from"./chunk-QKBEW6XH.js";import{$a as P,Na as I,Oa as d,Pa as p,Qa as g,Ra as S,Sa as f,Ta as x,Ua as k,Va as y,Wa as w,Xa as L,Ya as T,Za as v,_a as C,ab as M,bb as b,cb as a,db as D,p as o,sb as F}from"./chunk-6GIRXPOU.js";import{d as l}from"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{b as u}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as h}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as m,h as i,n as c}from"./chunk-DFBGNDRS.js";i();c();var t=m(h());i();c();var A=m(h());var z={[G]:a,vote:y,"vote-2":w,stake:L,"stake-2":T,view:v,chat:C,tip:P,mint:M,"mint-2":b,"generic-link":a,"generic-add":D,discord:I,twitter:d,"twitter-2":p,x:p,instagram:g,telegram:S,leaderboard:k,gaming:f,"gaming-2":x};function B({icon:s,...n}){let r=z[s];return A.default.createElement(r,{...n})}var E=o.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-top: -16px; // compensate for generic screen margins
`,H=o.footer`
  margin-top: auto;
  flex-shrink: 0;
  min-height: 16px;
`,Y=o.div`
  overflow: scroll;
`,_=o.ul`
  flex: 1;
  max-height: 350px;
  padding-top: 16px; // compensate for the override of the generic screen margins
`,j=o.li``,q=o.div`
  display: flex;
  align-items: center;
  padding: 6px 12px;
`,N=o(F)`
  text-align: left;
`;N.defaultProps={margin:"12px 0px"};function J({shortcuts:s,...n}){let r=(0,t.useMemo)(()=>n.hostname.includes("//")?new URL(n.hostname).hostname:n.hostname,[n.hostname]);return t.default.createElement(E,null,t.default.createElement(Y,null,t.default.createElement(_,null,s.map(e=>t.default.createElement(j,{key:e.uri},t.default.createElement(W,{type:"button",onClick:()=>{l.capture("walletShortcutsLinkOpenClick",O(n,e)),self.open(e.uri)},theme:"text",paddingY:6},t.default.createElement(q,null,t.default.createElement(B,{icon:V(e.uri,e.icon)})),e.label))))),t.default.createElement(H,null,r&&t.default.createElement(N,{color:"#777777",size:14,lineHeight:17},u("shortcutsWarningDescription",{url:r}))))}var ct=J;export{J as ShortcutsModal,ct as default};
//# sourceMappingURL=ShortcutsModal-RH4QIFFS.js.map
