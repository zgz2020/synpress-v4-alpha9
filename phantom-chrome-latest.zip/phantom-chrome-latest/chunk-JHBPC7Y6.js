import{c as p}from"./chunk-MY62I7BN.js";import{a}from"./chunk-4OIQVFXM.js";import{a as i}from"./chunk-MIHMJUVU.js";import{o as n,p as t}from"./chunk-6GIRXPOU.js";import{a as d}from"./chunk-GZ6YS23P.js";import{f as c,h as r,n as e}from"./chunk-DFBGNDRS.js";r();e();var o=c(d());var f=[1,2,3],m=50,l=350,h=m+l,I=n`
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
`,H=t(i).attrs({align:"center"})`
  height: ${h}px;
`,S=t(a).attrs({width:"100%",height:`${m}px`,margin:"0 0 20px 0",borderRadius:"6px",backgroundColor:"#2D2D2D"})``,L=()=>o.default.createElement(H,null,o.default.createElement(S,null),f.map(s=>o.default.createElement(p,{key:`fungible-token-row-${s}`})));export{L as a};
//# sourceMappingURL=chunk-JHBPC7Y6.js.map
