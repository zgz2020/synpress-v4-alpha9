import{j as m}from"./chunk-QKBEW6XH.js";import{p as t,sb as i,va as s}from"./chunk-6GIRXPOU.js";import{m as l}from"./chunk-FHPIWRKD.js";import{a}from"./chunk-GZ6YS23P.js";import{f as c,h as e,n as r}from"./chunk-DFBGNDRS.js";e();r();var o=c(a());var g=t.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`,h=t.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 90px;
`,u=t(i).attrs({size:28,weight:500})`
  margin-bottom: 8px;
  margin-top: 22px;
`,x=t(i).attrs({size:16,color:"#777"})`
  max-width: 275px;
  span {
    color: white;
  }
`,d=({onCancelClick:p})=>{let{t:n}=l();return o.default.createElement(g,null,o.default.createElement("div",null,o.default.createElement(h,null,o.default.createElement(s,{width:103,height:103}),o.default.createElement(u,null,n("notEnoughSolPrimaryText")),o.default.createElement(x,null,n("notEnoughSolSecondaryText")))),o.default.createElement(m,{onClick:p},n("commandCancel")))},w=d;export{d as a,w as b};
//# sourceMappingURL=chunk-W6KD4IJU.js.map
