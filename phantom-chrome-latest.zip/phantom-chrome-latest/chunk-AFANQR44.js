import{a as B}from"./chunk-LQRE2LU5.js";import{p as x}from"./chunk-W7GOV3UN.js";import{p as e,rb as f,sb as u}from"./chunk-6GIRXPOU.js";import{wc as g,xc as c}from"./chunk-5E46BDWA.js";import{md as m}from"./chunk-C7UIWCFX.js";import{S as l}from"./chunk-4G4LWPZS.js";import{a}from"./chunk-GZ6YS23P.js";import{f as s,h as i,n}from"./chunk-DFBGNDRS.js";i();n();var k=e.div`
  flex: 1;
  overflow: auto;
  padding: 20px 0;
`,z=e(k)`
  padding-top: 0;
  padding-bottom: 0;
`,P=e.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  flex: 1;
  padding: ${t=>t.size==="medium"?"20px":"30px"} 0 0;
`,S=e.section`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  > svg {
    margin-bottom: 16px;
  }
  > p {
    margin-bottom: 16px;
  }
`,E=e(u).attrs({size:16,lineHeight:22,weight:500,color:"#AB9FF2"})``,F=e.section`
  width: 100%;
  flex: 1;
  > * {
    margin-bottom: 10px;
  }
`,$=e(B).attrs({color:"#181818",diameter:94,includeDarkBoxShadow:!0})``,H=e.form`
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  ${F} {
    margin-top: 30px;
  }
`;i();n();var d=s(a());i();n();var p=s(a());var w=({text:t})=>p.default.createElement(b,null,p.default.createElement(C,null,t)),h=e.div`
  display: flex;
  align-items: center;
`,b=e.div`
  background: ${l("#FFFFFF",.1)};
  border-radius: 3px;
  padding: 0px 4px;
  color: white;
  display: inline-block;
  margin-left: 5px;
`,C=e(f).attrs({size:12,lineHeight:17,weight:600,noWrap:!0})``;var Z=({children:t,networkID:o,walletAddress:r})=>d.default.createElement(h,null,t,r?d.default.createElement(N,{networkID:o,address:r}):null),N=({networkID:t,address:o})=>{let r=y({networkID:t,address:o});return r?d.default.createElement(w,{text:r}):null},_=({networkID:t,address:o})=>{let r=y({networkID:t,address:o});return r?d.default.createElement(x,{children:r,size:"small"}):null},y=({networkID:t,address:o})=>{let r=m();return c(r,t)?g(t,o)??null:null};export{k as a,z as b,P as c,S as d,E as e,F as f,$ as g,H as h,b as i,Z as j,N as k,_ as l};
//# sourceMappingURL=chunk-AFANQR44.js.map
