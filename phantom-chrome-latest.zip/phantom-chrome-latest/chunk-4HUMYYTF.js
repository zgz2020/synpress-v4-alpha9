import{c as h}from"./chunk-5MHIOR4A.js";import{g as C}from"./chunk-JLCEGUNG.js";import{p as r}from"./chunk-6GIRXPOU.js";import{a as x,b}from"./chunk-GI2DVDG3.js";import{a as L}from"./chunk-AVQ5BBEB.js";import{ka as w,u as v}from"./chunk-4G4LWPZS.js";import{Ya as q}from"./chunk-LI5RB3LP.js";import{a as P}from"./chunk-GZ6YS23P.js";import{f as R,h as c,n as d}from"./chunk-DFBGNDRS.js";c();d();var o=R(P()),p=R(L());var N={isConnected:!1,lastMessage:null,postMessage:w},y=o.default.createContext(N),D=({children:e})=>{let[n,i,u]=O();return o.default.createElement(y.Provider,{value:{isConnected:n,lastMessage:i,postMessage:u}},e)};function O(){let[e,n]=(0,o.useState)(null),[i,u]=(0,o.useState)(null),{data:[l],isLoading:g}=q(["enable-sidepanel-tx-notifications"]),m=t=>{let s=b(t);!s||typeof s.url!="string"||!s.url||!s.req||typeof s.req.method!="string"||!s.req.method||u({...s,url:v(s.url.toString())})};(0,o.useEffect)(()=>{},[]),(0,o.useEffect)(()=>{let t;return g||(async()=>{if(l===!0&&await h()){let f=a=>{a.name==="popup/sidepanel"&&(n(a),a.onMessage.addListener(m),a.onDisconnect.addListener(()=>{n(null),u(null)}))};p.default.runtime.onConnect.addListener(f)}else{let a=`notification/${(await C()).id}`;t=p.default.runtime.connect({name:a}),n(t),t.onMessage.addListener(m),t.onDisconnect.addListener(()=>{self.close(),n(null),u(null)})}})(),()=>{t?.disconnect()}},[g,l]);let I=(0,o.useCallback)(t=>{e&&e.postMessage(x(t))},[e]);return[!!e,i,I]}function B(){let e=(0,o.useContext)(y);if(!e)throw new Error("Missing background connection context");return e}function A(){let{lastMessage:e}=B();return e}function J(){let e=A(),{postMessage:n}=B();return(0,o.useCallback)(i=>{if(e){if(e.req.id!==i.id)throw new Error(`Request id: ${e.req.id} does not match response id: ${i.id}`);n(i)}else throw new Error("No request received from the background yet")},[e,n])}c();d();c();d();var M=r.div`
  ${e=>!e.plain&&`
    background-color: ${e.theme?.footer?.backgroundColor??"#2b2b2b"};
    border-top: ${e.theme?.footer?.borderTop??"1px solid #323232"};
    box-shadow: ${e.theme?.footer?.boxShadow??"0px -6px 10px rgba(0, 0, 0, 0.25)"};
  `}
`;var X=r.div`
  flex: none;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;

  > * {
    margin-top: 27px;
  }
`,Y=r.div`
  flex: 1;
  overflow: auto;
  padding: 0px 16px;
`,Z=r.div`
  position: fixed;
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  left: 0;
  bottom: 0;
  background: #222222;
`,ee=r(M)`
  flex: none;
  padding: 14px 20px;
`,oe=r.div`
  padding: 20px;
  height: 100%;
`;export{D as a,A as b,J as c,M as d,X as e,Y as f,Z as g,ee as h,oe as i};
//# sourceMappingURL=chunk-4HUMYYTF.js.map
