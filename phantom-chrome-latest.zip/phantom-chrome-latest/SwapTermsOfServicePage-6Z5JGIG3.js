import{Ka as T}from"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import"./chunk-KRKHMYSL.js";import"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import"./chunk-CBMCHMBG.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import{a as S}from"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{k as u}from"./chunk-QKBEW6XH.js";import{oa as d,p as o,sb as t}from"./chunk-6GIRXPOU.js";import{Ra as f}from"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as p}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import{C as a,D as m}from"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as y}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as v,h as c,n as l}from"./chunk-DFBGNDRS.js";c();l();var e=v(y());var w=o.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: 100%;
  width: 100%;
  overflow-y: scroll;
  padding: 16px;
`,C=o.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-top: -20px;
`,g=o(t).attrs({size:28,weight:500,color:"#FFFFFF"})`
  margin-top: 24px;
`,x=o(t).attrs({size:16,weight:500,color:"#777777"})`
  padding: 0px 5px;
  margin-top: 9px;
  span {
    color: #ffffff;
  }
  label {
    color: #ab9ff2;
    cursor: pointer;
  }
`,O=o.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  height: fit-content;
`,b=o.div`
  margin-top: auto;
  width: 100%;
`,k=()=>{let{t:i}=p(),{mutateAsync:n}=f(),{handleHideModalVisibility:r,handleShowModalVisibility:s}=T();return{onAgreeClick:(0,e.useCallback)(()=>{n(!0),s("swapReview"),r("swapTermsOfService")},[s,n,r]),onCancelClick:()=>{r("swapTermsOfService")},t:i}},h=()=>{self.open(a,"_blank")},P=()=>{self.open(m,"_blank")},F=e.default.memo(({onAgreeClick:i,onCancelClick:n,t:r})=>e.default.createElement(w,null,e.default.createElement(C,null,e.default.createElement(O,null,e.default.createElement(d,null),e.default.createElement(g,null,r("termsOfServicePrimaryText")),e.default.createElement(x,null,e.default.createElement(S,{i18nKey:"termsOfServiceDiscliamerFeesEnabledInterpolated"},"We have revised our Terms of Service. By clicking ",e.default.createElement("span",null,'"I Agree"')," you agree to our new",e.default.createElement("label",{onClick:h},"Terms of Service"),".",e.default.createElement("br",null),e.default.createElement("br",null),"Our new Terms of Service include a new ",e.default.createElement("label",{onClick:P},"fee structure")," for certain products.")))),e.default.createElement(b,null,e.default.createElement(u,{primaryText:r("termsOfServiceActionButtonAgree"),secondaryText:r("commandCancel"),onPrimaryClicked:i,onSecondaryClicked:n})))),A=()=>{let i=k();return e.default.createElement(F,{...i})},U=A;export{A as SwapTermsOfServicePage,U as default};
//# sourceMappingURL=SwapTermsOfServicePage-6Z5JGIG3.js.map
