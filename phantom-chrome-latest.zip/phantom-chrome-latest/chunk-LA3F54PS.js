import{Fa as t}from"./chunk-6GIRXPOU.js";import{a as n}from"./chunk-GZ6YS23P.js";import{f as m,h as r,n as o}from"./chunk-DFBGNDRS.js";r();o();var e=m(n());var p=e.default.memo(({width:i=48,fill:l="#474747"})=>e.default.createElement(t,{width:i,height:i,fill:l}));export{p as a};
//# sourceMappingURL=chunk-LA3F54PS.js.map
