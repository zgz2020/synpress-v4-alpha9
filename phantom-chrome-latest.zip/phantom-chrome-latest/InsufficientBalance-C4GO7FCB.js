import{a as h,b as c,d as s,e as T}from"./chunk-RT4N3TM6.js";import{a as I}from"./chunk-37XRAS64.js";import{Ka as b,ea as g}from"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import"./chunk-KRKHMYSL.js";import"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import"./chunk-CBMCHMBG.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{j as x,k as C}from"./chunk-QKBEW6XH.js";import{p as o,sb as l}from"./chunk-6GIRXPOU.js";import"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import{Pa as r,Va as y,hb as B}from"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import{m as d}from"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as v}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as S,h as p,n as u}from"./chunk-DFBGNDRS.js";p();u();var n=S(v());var M=o.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  overflow-y: scroll;
`,D=o.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 90px;
`,P=o(l).attrs({size:28,weight:500,color:"#FFF"})`
  margin: 16px;
`,V=o(l).attrs({size:14,weight:400,lineHeight:17,color:"#999"})`
  max-width: 275px;

  span {
    color: white;
  }
`,$=o(h)`
  width: 100%;
  margin-top: 32px;
`,q=({networkId:t,token:a})=>{let{t:i}=d(),{handleHideModalVisibility:f}=b(),m=(0,n.useCallback)(()=>{f("insufficientBalance")},[f]),w=t&&y(B(r.getChainID(t))),{canBuy:F,openBuy:k}=g(w||"","modal","fiatOnrampFromInsufficientBalance"),e=t?r.getTokenSymbol(t):i("tokens");return n.default.createElement(M,null,n.default.createElement("div",null,n.default.createElement(D,null,n.default.createElement(I,{type:"failure",backgroundWidth:75}),n.default.createElement(P,null,i("insufficientBalancePrimaryText",{tokenSymbol:e})),n.default.createElement(V,null,i("insufficientBalanceSecondaryText",{tokenSymbol:e})),a?n.default.createElement($,{roundedTop:!0,roundedBottom:!0},n.default.createElement(c,{label:i("insufficientBalanceRemaining")},n.default.createElement(s,{color:"#EB3742"},`${a.balance} ${e}`)),n.default.createElement(T,{gap:1}),n.default.createElement(c,{label:i("insufficientBalanceRequired")},n.default.createElement(s,null,`${a.required} ${e}`))):null)),F?n.default.createElement(C,{primaryText:i("buyAssetInterpolated",{tokenSymbol:e}),onPrimaryClicked:k,secondaryText:i("commandCancel"),onSecondaryClicked:m}):n.default.createElement(x,{onClick:m},i("commandCancel")))},Q=q;export{q as InsufficientBalance,Q as default};
//# sourceMappingURL=InsufficientBalance-C4GO7FCB.js.map
