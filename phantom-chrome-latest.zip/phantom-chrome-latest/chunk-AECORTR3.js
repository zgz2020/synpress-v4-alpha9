import{p as r}from"./chunk-6GIRXPOU.js";import{h as i,n}from"./chunk-DFBGNDRS.js";i();n();var s={width:"100%",align:"center",justify:"flex-start"},e=r.div`
  display: flex;
  flex-direction: row;
  width: ${t=>t.width};
  margin: ${t=>t.margin};
  padding: ${t=>t.padding};
  align-items: ${t=>t.align};
  justify-content: ${t=>t.justify};
`;e.defaultProps=s;export{e as a};
//# sourceMappingURL=chunk-AECORTR3.js.map
