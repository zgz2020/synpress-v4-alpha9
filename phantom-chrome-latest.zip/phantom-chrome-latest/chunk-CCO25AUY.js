import{a as C,b as _}from"./chunk-YKQBTVPZ.js";import{a as g}from"./chunk-MUPQ6ZPZ.js";import{a as v,l as D}from"./chunk-AFANQR44.js";import{c as I}from"./chunk-YVMSPJ5X.js";import{a as P}from"./chunk-MIHMJUVU.js";import{m as H,n as S}from"./chunk-KRKHMYSL.js";import{a as w,g as T}from"./chunk-W7GOV3UN.js";import{j as B}from"./chunk-QKBEW6XH.js";import{A as b,p as t,sb as c}from"./chunk-6GIRXPOU.js";import{Jb as y,Pa as x,yb as k}from"./chunk-C7UIWCFX.js";import{m as u}from"./chunk-FHPIWRKD.js";import{a as h}from"./chunk-GZ6YS23P.js";import{f as l,h as m,n as a}from"./chunk-DFBGNDRS.js";m();a();var p=l(h());var ro=p.default.memo(({chainAddress:i,onQRClick:d})=>{let{networkID:s,address:e}=i,{t:n}=u(),{buttonText:f,copied:W,copy:A}=C(e),E=y(e,4),L=n(x.getNetworkName(s)),M=(0,p.useCallback)(O=>{O.stopPropagation(),A()},[A]);return p.default.createElement(T,{copied:W,copiedText:f,formattedAddress:E,networkBadge:p.default.createElement(D,{networkID:s,address:e}),networkLogo:p.default.createElement(g,{networkID:s,size:40}),networkName:L,onCopyClick:M,onQRClick:d})});m();a();var Q=l(_()),o=l(h());m();a();var r=l(h());var j=t.div`
  width: 100%;
`,F=t(I)`
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 6px 6px 0 0;
  border-bottom: none;
  margin: 0;
  padding: 16px 22px;
  font-size: 16px;
  font-weight: 500;
  line-height: 21px;
  text-align: center;
  resize: none;
  overflow: hidden;
`,U=t.button`
  display: flex;
  justify-content: center;
  align-items: center;
  background: #181818;
  border: 1px solid #2f2f2f;
  border-radius: 0 0 6px 6px;
  border-top: none;
  height: 40px;
  width: 100%;
  padding: 0;
  cursor: pointer;

  &:hover {
    background: #1c1c1c;
  }
`,q=t(c).attrs({size:16,weight:600,lineHeight:16})`
  margin-left: 6px;
`,z=({value:i})=>{let{buttonText:d,copy:s}=C(i),e=(0,r.useRef)(null);return(0,r.useEffect)(()=>{(()=>{if(e&&e.current){let f=e.current.scrollHeight;e.current.style.height=f+"px"}})()},[]),r.default.createElement(j,null,r.default.createElement(F,{ref:e,readOnly:!0,value:i}),r.default.createElement(U,{onClick:s},r.default.createElement(b,null),r.default.createElement(q,null,d)))};var G=48,So=o.default.memo(({address:i,networkID:d,headerType:s,onCloseClick:e})=>{let{t:n}=u();return o.default.createElement(o.default.Fragment,null,o.default.createElement(s==="page"?H:S,null,n("depositAddress")),o.default.createElement(v,null,o.default.createElement(P,{align:"center",justify:"center",id:"column"},o.default.createElement(Z,{id:"QRCodeWrapper"},o.default.createElement(R,{value:i,size:160,level:"Q",id:"styledqrcode"}),o.default.createElement(g,{networkID:d,size:G,borderColor:"bgWallet",className:w({position:"absolute"})}))),o.default.createElement(c,{size:16,lineHeight:22,weight:600,margin:"16px 0 8px"},n("depositAddressChainInterpolated",{chain:x.getNetworkName(d)})),o.default.createElement(z,{value:i}),o.default.createElement(c,{size:14,color:"#777777",lineHeight:20,margin:"16px 0"},n("depositAssetSecondaryText")," ",o.default.createElement(J,{href:k,target:"_blank",rel:"noopener noreferrer"},n("commandLearnMore")))),o.default.createElement(B,{onClick:e},n("commandClose")))}),R=t(Q.default)`
  padding: 8px;
  background: #ffffff;
  border-radius: 6px;
  position: relative;
`,Z=t.div`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
`,J=t.a`
  color: #ab9ff2;
  text-decoration: none;
  font-weight: 500;
`;export{ro as a,z as b,So as c};
//# sourceMappingURL=chunk-CCO25AUY.js.map
