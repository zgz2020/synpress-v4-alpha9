import{a as s}from"./chunk-GZ6YS23P.js";import{c as n,h as u,n as t}from"./chunk-DFBGNDRS.js";var a=n(e=>{"use strict";u();t();Object.defineProperty(e,"__esModule",{value:!0});var c=s();function i(f){var r=c.useRef();return c.useEffect(function(){r.current=f}),r.current}e.default=i});export{a};
//# sourceMappingURL=chunk-BCCJIU7J.js.map
