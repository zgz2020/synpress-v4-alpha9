import{I as r}from"./chunk-LI5RB3LP.js";import{f as p,h as t,n as o}from"./chunk-DFBGNDRS.js";t();o();var e=p(r()),s=e.default.parse(typeof navigator<"u"?navigator.userAgent:"Chrome"),E=360,_=600,a=59,c="modal";var H="https://help.phantom.app/hc/en-us/requests/new?ticket_form_id=1500002752382";export{s as a,E as b,_ as c,a as d,c as e,H as f};
//# sourceMappingURL=chunk-E5NQVP5E.js.map
