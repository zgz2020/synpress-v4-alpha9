import{l as n,p as m,sb as d}from"./chunk-6GIRXPOU.js";import{r as p}from"./chunk-E3SVBH7I.js";import{Zd as l}from"./chunk-C7UIWCFX.js";import{S as s}from"./chunk-4G4LWPZS.js";import{a as h}from"./chunk-GZ6YS23P.js";import{f as T,h as a,n as c}from"./chunk-DFBGNDRS.js";a();c();var t=T(h());var v=o=>{let{txHash:e}=o,{data:i}=l("solana"),f=e&&i?{id:e,networkID:i}:void 0,{data:r}=p(f),x=(0,t.useCallback)(()=>{r&&self.open(r)},[r]);return t.default.createElement(w,{opacity:e?1:0,onClick:x},o.children)},w=m(d).attrs({size:16,weight:500,color:"#AB9FF2"})`
  margin-top: 18px;
  text-decoration: none;
  ${o=>o.opacity===0?n`
          pointer-events: none;
        `:n`
          &:hover {
            cursor: pointer;
            color: ${s("#e2dffe",.5)};
          }
        `}
  }
`;export{v as a};
//# sourceMappingURL=chunk-3AGMJ47K.js.map
