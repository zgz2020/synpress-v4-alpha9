import{ce as t}from"./chunk-C7UIWCFX.js";import{h as i,n as o}from"./chunk-DFBGNDRS.js";i();o();var u={publicFungibleDetailProps:null},b=t(e=>({...u,setNotifyHomeFungiblePush:l=>e({publicFungibleDetailProps:l}),clearNotifyHomeFungiblePush:()=>e({publicFungibleDetailProps:null})}));export{b as a};
//# sourceMappingURL=chunk-2AFHMKMT.js.map
