import{h as e,i as n,n as r}from"./chunk-DFBGNDRS.js";e();r();var s=()=>n.ENVIRONMENT==="e2e";export{s as a};
//# sourceMappingURL=chunk-2GWJ7IQN.js.map
