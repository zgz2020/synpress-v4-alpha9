import{a as u}from"./chunk-GZ6YS23P.js";import{f as o,h as r,n as f}from"./chunk-DFBGNDRS.js";r();f();var e=o(u()),s=(c,n)=>{let t=(0,e.useRef)(!1);(0,e.useEffect)(()=>{if(!(t.current||!n))return t.current=!0,c()})};export{s as a};
//# sourceMappingURL=chunk-G7QRF4HP.js.map
