import{fa as n}from"./chunk-FDXJ5SY6.js";import{B as e}from"./chunk-E3SVBH7I.js";import{sb as o,yd as r}from"./chunk-C7UIWCFX.js";import{h as a,n as t}from"./chunk-DFBGNDRS.js";a();t();var c=async i=>{await o(i),await Promise.all([r,e,n].map(m=>m(i)))};export{c as a};
//# sourceMappingURL=chunk-3TXGUWHR.js.map
