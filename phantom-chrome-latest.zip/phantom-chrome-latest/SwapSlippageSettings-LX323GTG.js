import{G as w,Ka as S}from"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import"./chunk-KRKHMYSL.js";import{a as C}from"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import"./chunk-CBMCHMBG.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{j as h}from"./chunk-QKBEW6XH.js";import{p as o,sa as x,sb as a}from"./chunk-6GIRXPOU.js";import{xa as f}from"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import"./chunk-FHPIWRKD.js";import"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as k}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as b,h as m,n as u}from"./chunk-DFBGNDRS.js";m();u();var e=b(k());var O=o.div`
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 16px;
`,T=o.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  margin: 20px 0 16px;
  width: 100%;
`,F=o(a).attrs({size:28,lineHeight:32,weight:600,color:"#fff"})`
  margin: 20px 0 12px;
`,I=o(a).attrs({size:16,lineHeight:18,weight:400,color:"#777777"})`
  margin-bottom: 32px;
`,H=o.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  padding: 2px;
  width: 100%;
  background-color: ${t=>t.theme.backgroundDark};
`,P=o.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  padding: 10px 8px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  background-color: ${t=>t.selected?"#AB9FF2":"transparent"};
  cursor: pointer;
`,y=o(a).attrs(t=>({size:14,lineHeight:18,weight:t.selected?600:500,color:t.selected?"#222":"#fff"}))`
  text-align: center;
`,V=o(a).attrs(t=>({size:14,lineHeight:18,weight:500,color:t.severity==="critical"?"#EB3742":"#FFDC62"}))`
  align-self: stretch;
  margin-top: 8px;
  text-align: left;
`,B=o.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`,z=o.input`
  background: transparent;
  color: #222;
  ::placeholder {
    color: #22222299;
  }
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 18px;
  text-align: right;
  border: none;
  padding: 0;
`,D=()=>{let{handleHideModalVisibility:t}=S(),i=(0,e.useCallback)(()=>{t("slippageSettings")},[t]);return f({onDismiss:i})},E=({options:t,selectedIndex:i,customSlippageValue:r,i18nStrings:n,error:l,submitDisabled:g,onConfirm:c,onSelectOption:s,onChangeCustomSlippage:p,onDismiss:d})=>e.default.createElement(O,null,e.default.createElement(w,{leftButton:{type:"close",onClick:d},titleSize:"small"},n.title),e.default.createElement(T,null,e.default.createElement(C,{diameter:96,color:"#181818"},e.default.createElement(x,{width:38,fill:"#181818"})),e.default.createElement(F,null,n.title),e.default.createElement(I,null,n.subtitle),e.default.createElement(L,{options:t,selectedIndex:i,customOptionLabel:n.custom,customOptionValue:r,onSelectOption:s,onCustomOptionChange:p}),l?e.default.createElement(V,{severity:l.severity},l.message):null),e.default.createElement(h,{disabled:g,theme:"primary",onClick:c},n.button)),j=()=>{let t=D();return e.default.createElement(E,{...t})},Q=j,A=({value:t,onChangeText:i})=>{let r=n=>{n.target.validity.valid?i(n.target.value):n.preventDefault()};return e.default.createElement(B,null,e.default.createElement(z,{autoFocus:!t,placeholder:"0.00%",value:t??"",style:t?{width:`${t.length*10}px`,textAlign:"right"}:{width:"100%",textAlign:"center"},onChange:r}),e.default.createElement(y,{selected:!0},t?"%":""))},L=({options:t,selectedIndex:i,customOptionLabel:r,customOptionValue:n,onSelectOption:l,onCustomOptionChange:g})=>e.default.createElement(H,null,t.map((c,s)=>{let p=s===i,d=s===t.length-1&&p,v=()=>l(s);return e.default.createElement(P,{key:`segment-control-option-${s}`,selected:p,onClick:v},d?e.default.createElement(A,{value:n,onChangeText:g}):e.default.createElement(y,{selected:p},c==="custom"?r:c))}));export{j as SwapSlippageSettings,Q as default};
//# sourceMappingURL=SwapSlippageSettings-LX323GTG.js.map
