import{a as F,c as L,d as N,g as D}from"./chunk-KSIPW2X5.js";import{a as g}from"./chunk-VWTNNTMA.js";import"./chunk-37XRAS64.js";import"./chunk-A7G3RXY5.js";import"./chunk-MUPQ6ZPZ.js";import{a as _}from"./chunk-G7QRF4HP.js";import"./chunk-K2OL5ZN2.js";import"./chunk-AIOERECL.js";import"./chunk-X7BGQIYK.js";import"./chunk-MY62I7BN.js";import"./chunk-E35ZFQTP.js";import"./chunk-2W5BBP6V.js";import"./chunk-6MGZDMDL.js";import"./chunk-PPXUY6SE.js";import"./chunk-GBGLUPZY.js";import"./chunk-4OIQVFXM.js";import"./chunk-SBNVSNC5.js";import"./chunk-TZNSHZMJ.js";import{a as T}from"./chunk-AECORTR3.js";import"./chunk-N5GD7FDS.js";import"./chunk-LVT7IYXJ.js";import"./chunk-44NLMB3W.js";import"./chunk-AFANQR44.js";import"./chunk-YVMSPJ5X.js";import"./chunk-W4CPTUAB.js";import"./chunk-MIHMJUVU.js";import{e as $}from"./chunk-KRKHMYSL.js";import{a as m}from"./chunk-LQRE2LU5.js";import"./chunk-7DJ4CCJR.js";import"./chunk-CBMCHMBG.js";import"./chunk-5MHIOR4A.js";import{a as f}from"./chunk-L6W3DLX6.js";import"./chunk-VCWUNILH.js";import"./chunk-5AOFHNI3.js";import"./chunk-KHXNW2QG.js";import"./chunk-DXULVEAG.js";import"./chunk-JLCEGUNG.js";import"./chunk-W7GOV3UN.js";import"./chunk-UTMR6LRT.js";import"./chunk-OTYPEXQP.js";import"./chunk-XAQ5W2UN.js";import"./chunk-4LVTEXBT.js";import"./chunk-HJRPBBDR.js";import{a as E,b as P}from"./chunk-QKBEW6XH.js";import{p as c,w as O}from"./chunk-6GIRXPOU.js";import"./chunk-FDXJ5SY6.js";import"./chunk-GI2DVDG3.js";import"./chunk-HBQQ4U72.js";import"./chunk-KN36XKD6.js";import"./chunk-FZCSOTU6.js";import"./chunk-S2EL3BEE.js";import"./chunk-E5NQVP5E.js";import"./chunk-OTWAQNOL.js";import"./chunk-ETHRQ36O.js";import"./chunk-ZEEEI4EC.js";import"./chunk-AVQ5BBEB.js";import"./chunk-E3SVBH7I.js";import"./chunk-5E46BDWA.js";import"./chunk-LG4SRAA6.js";import"./chunk-R6VELCKZ.js";import"./chunk-LZD3LM4X.js";import"./chunk-TYPDY4PB.js";import"./chunk-4E6OUISL.js";import"./chunk-CLXZ3HZN.js";import"./chunk-X4PFTUHE.js";import{Ed as B,wd as v}from"./chunk-C7UIWCFX.js";import"./chunk-RKVXP75K.js";import"./chunk-FHPIWRKD.js";import{g as y}from"./chunk-4G4LWPZS.js";import"./chunk-LI5RB3LP.js";import"./chunk-USRKY7I6.js";import{a as H}from"./chunk-GZ6YS23P.js";import"./chunk-A5HFQBEI.js";import{f as b,h as r,n}from"./chunk-DFBGNDRS.js";r();n();var o=b(H());r();n();var i=b(H());r();n();var G=c(m)`
  cursor: pointer;
  width: 24px;
  height: 24px;
  transition: background-color 200ms ease;
  background-color: ${t=>t.$isExpanded?"#000":"#333"} !important;
  :hover {
    background-color: #444444;
    svg {
      fill: white;
    }
  }
  svg {
    fill: ${t=>t.$isExpanded?"white":"#666666"};
    transition: fill 200ms ease;
    position: relative;
    ${t=>t.top?`top: ${t.top}px;`:""}
    ${t=>t.right?`right: ${t.right}px;`:""}
  }
`;var U=c(T).attrs({justify:"space-between"})`
  background-color: #222222;
  padding: 10px 16px;
  border-bottom: 1px solid #323232;
  height: 46px;
  opacity: ${t=>t.opacity??"1"};
`,V=c.div`
  display: flex;
  margin-left: 10px;
  > * {
    margin-right: 10px;
  }
`,I=c.div`
  width: 24px;
  height: 24px;
`,M=({onBackClick:t,totalSteps:a,currentStepIndex:p,isHidden:l,showBackButtonOnFirstStep:e,showBackButton:u=!0})=>i.default.createElement(U,{opacity:l?0:1},u&&(e||p!==0)?i.default.createElement(G,{right:1,onClick:t},i.default.createElement(O,null)):i.default.createElement(I,null),i.default.createElement(V,null,y(a).map(s=>{let d=s<=p?"#AB9FF2":"#333";return i.default.createElement(m,{key:s,diameter:12,color:d})})),i.default.createElement(I,null));r();n();var z=()=>{let{mutateAsync:t}=B(),{hardwareStepStack:a,pushStep:p,popStep:l,currentStep:e,setOnConnectHardwareAccounts:u,setOnConnectHardwareDone:w,setExistingAccounts:s}=F(),{data:d=[],isFetched:x,isError:k}=v(),C=$(a,(h,J)=>h?.length===J.length),W=a.length>(C??[]).length,A=C?.length===0,X={initial:{x:A?0:W?150:-150,opacity:A?1:0},animate:{x:0,opacity:1},exit:{opacity:0},transition:{duration:.2}},j=(0,o.useCallback)(()=>{e()?.props.preventBack||(e()?.props.onBackCallback&&e()?.props.onBackCallback?.(),l())},[e,l]);return _(()=>{u(async h=>{await t(h),await f.set(g,!await f.get(g))}),w(()=>self.close()),p(o.default.createElement(D,null))},a.length===0),(0,o.useEffect)(()=>{s({data:d,isFetched:x,isError:k})},[d,x,k,s]),o.default.createElement(L,null,o.default.createElement(M,{totalSteps:3,onBackClick:j,showBackButton:!e()?.props.preventBack,currentStepIndex:a.length-1}),o.default.createElement(P,{mode:"wait"},o.default.createElement(E.div,{style:{display:"flex",flexGrow:1},key:`${a.length}_${C?.length}`,...X},o.default.createElement(N,null,e()))))},yt=z;export{yt as default};
//# sourceMappingURL=SettingsConnectHardware-RHHNQLCH.js.map
