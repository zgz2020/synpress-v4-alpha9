import{b as p}from"./chunk-LVT7IYXJ.js";import{a as i}from"./chunk-MIHMJUVU.js";import{a as g}from"./chunk-LQRE2LU5.js";import{j as c}from"./chunk-QKBEW6XH.js";import{p as n,sb as t,wa as a}from"./chunk-6GIRXPOU.js";import{m}from"./chunk-FHPIWRKD.js";import{S as s}from"./chunk-4G4LWPZS.js";import"./chunk-USRKY7I6.js";import{a as d}from"./chunk-GZ6YS23P.js";import{f,h as e,n as l}from"./chunk-DFBGNDRS.js";e();l();var o=f(d());var u=n(i).attrs({align:"center",justify:"space-between"})`
  height: 100%;
`,x=n(i).attrs({align:"center",justify:"center"})`
  height: 100%;
`,h=n(g)`
  svg {
    fill: #e5a221;
  }
`,L=()=>{let{t:r}=m(),{hideListingsErrorModal:C}=p();return o.default.createElement(u,null,o.default.createElement(x,null,o.default.createElement(i,{align:"center",margin:"0 0 20px 0"},o.default.createElement(h,{color:s("#E5A221",.1),diameter:94},o.default.createElement(a,{fill:"#E5A221"}))),o.default.createElement(i,{align:"center",margin:"0 0 10px 0"},o.default.createElement(t,{size:26,weight:500,lineHeight:34},r("collectiblesUnableToLoadListings"))),o.default.createElement(i,{align:"center",padding:"0 20px"},o.default.createElement(t,{size:16,color:"#777777",lineHeight:22},r("collectiblesUnableToLoadListingsDescription",{marketplace:"Magic Eden"})))),o.default.createElement(c,{onClick:C},r("commandClose")))},z=L;export{L as ListingsErrorPage,z as default};
//# sourceMappingURL=ListingsErrorPage-6YERZZNO.js.map
