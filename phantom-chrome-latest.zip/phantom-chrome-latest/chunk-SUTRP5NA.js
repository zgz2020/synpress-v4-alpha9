import{d}from"./chunk-VCWUNILH.js";import{z as u}from"./chunk-5AOFHNI3.js";import{b as p}from"./chunk-JLCEGUNG.js";import{a as m,c as e,d as i,e as c}from"./chunk-W7GOV3UN.js";import{p as g}from"./chunk-6GIRXPOU.js";import{m as a}from"./chunk-FHPIWRKD.js";import{A as l,B as s}from"./chunk-LI5RB3LP.js";import{a as y}from"./chunk-GZ6YS23P.js";import{f as k,h as r,n}from"./chunk-DFBGNDRS.js";r();n();var o=k(y());var L=g.a`
  transition-timing-function: cubic-bezier(0.16, 1, 0.3, 1);
  transition-duration: 250ms;
  transition-property: color;
  &:hover {
    svg {
      opacity: 0.8;
    }
  }
`,H=()=>{let{t}=a(),{downloadLogs:f,goCreateTicket:b}=d();return o.default.createElement(i,{direction:"row",justifyContent:"space-between",alignItems:"center",className:m({position:"absolute",top:0,right:0,left:0,paddingY:32,paddingX:40})},o.default.createElement(L,{href:s,target:"_blank",rel:"noopener noreferrer"},o.default.createElement(e.LogoFill,{size:36,color:"bgWallet"})),o.default.createElement(u,{items:[{label:t("settingsSupportDesk"),key:t("settingsSupportDesk"),onClick:()=>p({url:l})},{label:t("settingsSubmitATicket"),key:t("settingsSubmitATicket"),onClick:b},{label:t("settingsDownloadApplicationLogs"),key:t("settingsDownloadApplicationLogs"),onClick:f}]},o.default.createElement(i,{direction:"row",alignItems:"center",gap:6,cursor:"pointer"},o.default.createElement(e.HelpCircle,{size:20,color:"accentPrimaryLight",fill:"bgWallet"}),o.default.createElement(c,{children:t("fullPageHeaderHelp"),font:"bodyMedium",color:"bgWallet"}))))};export{H as a};
//# sourceMappingURL=chunk-SUTRP5NA.js.map
